Project:
Long Assignment 1

Group Members:
Benjamin Arthur Kanter
Davranbek Azatovich Kadirimbetov

Grader:
Jenny
